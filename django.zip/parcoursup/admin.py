from django.contrib import admin
from .models import School, Course, Candidate

admin.site.register(School)
admin.site.register(Course)
admin.site.register(Candidate)
